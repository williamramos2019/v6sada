
CREATE TABLE "equipment_substitutions" (
	"id" varchar PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"rental_id" varchar NOT NULL,
	"old_equipment_name" text NOT NULL,
	"new_equipment_name" text NOT NULL,
	"substitution_reason" text NOT NULL,
	"supplier_responsible" text,
	"substitution_date" timestamp NOT NULL,
	"delivery_photos" text[],
	"receipt_photos" text[],
	"notes" text,
	"supplier_notes" text,
	"responsibility_shift" boolean DEFAULT false,
	"additional_costs" numeric(10, 2) DEFAULT '0',
	"created_at" timestamp DEFAULT now(),
	"updated_at" timestamp DEFAULT now()
);
--> statement-breakpoint
ALTER TABLE "equipment_substitutions" ADD CONSTRAINT "equipment_substitutions_rental_id_rentals_id_fk" FOREIGN KEY ("rental_id") REFERENCES "public"."rentals"("id") ON DELETE no action ON UPDATE no action;
